<template>
    <view class="content">
        <web-view src="/static/home/contact.html"></web-view>
    </view>
</template>
<script>
    export default {
        componeants: {

        },
        data() {
            return {

            }
        },
        onLoad() {

        },
        methods: {
            gopay: function() {

            },
        }
    }
</script>

<style lang="less">
    .content {}
</style>
