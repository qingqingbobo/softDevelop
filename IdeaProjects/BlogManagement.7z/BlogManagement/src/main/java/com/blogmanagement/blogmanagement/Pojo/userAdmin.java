package com.blogmanagement.blogmanagement.Pojo;

import lombok.Data;

@Data
public class userAdmin {
    private Integer id;
    private String user_num;
    private String user_pass;
    private String add_time;
}