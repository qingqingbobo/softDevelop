package com.blogmanagement.blogmanagement.Pojo;

import lombok.Data;

@Data
public class Categories {

  private Integer value;
  private String name;
}
