package com.blogmanagement.blogmanagement.Pojo;

import lombok.Data;

@Data
public class Creationage {

  private String name;
  private Integer value;

}




