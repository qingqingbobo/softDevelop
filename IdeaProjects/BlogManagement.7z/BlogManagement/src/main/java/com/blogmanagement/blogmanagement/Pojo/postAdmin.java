package com.blogmanagement.blogmanagement.Pojo;

import lombok.Data;

@Data
public class postAdmin {
    private Integer id;
    private String post_name;
    private String post_author;
    private Integer post_readnum;
}
