package com.blogmanagement.blogmanagement.Pojo;

import lombok.Data;

@Data
public class Phonenum {
    private String phonenum;
}
