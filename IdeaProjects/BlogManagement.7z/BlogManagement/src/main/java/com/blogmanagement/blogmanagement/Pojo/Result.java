package com.blogmanagement.blogmanagement.Pojo;

import lombok.Data;

@Data
public class Result {
    private Integer code;
    private Object result;

}
