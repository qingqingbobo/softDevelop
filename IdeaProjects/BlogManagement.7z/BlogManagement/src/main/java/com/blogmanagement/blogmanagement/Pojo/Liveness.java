package com.blogmanagement.blogmanagement.Pojo;

import lombok.Data;

@Data
public class Liveness {
private String date;
private long num;
}
