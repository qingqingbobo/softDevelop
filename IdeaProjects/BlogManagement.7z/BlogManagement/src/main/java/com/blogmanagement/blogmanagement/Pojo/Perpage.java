package com.blogmanagement.blogmanagement.Pojo;

import lombok.Data;

@Data
public class Perpage {
    private int perpage;
    private int page;
    private String key;
}
