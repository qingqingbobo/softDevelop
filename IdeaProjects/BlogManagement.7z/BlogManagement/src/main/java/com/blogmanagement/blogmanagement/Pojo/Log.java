package com.blogmanagement.blogmanagement.Pojo;

import lombok.Data;

@Data
public class Log {
    private Integer id;
    private String loginlog;
    private String editlog;
}

