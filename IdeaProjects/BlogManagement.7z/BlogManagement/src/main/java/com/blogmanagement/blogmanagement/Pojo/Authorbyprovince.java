package com.blogmanagement.blogmanagement.Pojo;

import lombok.Data;

@Data
public class Authorbyprovince {
    private String name;

    private Integer value;
}
