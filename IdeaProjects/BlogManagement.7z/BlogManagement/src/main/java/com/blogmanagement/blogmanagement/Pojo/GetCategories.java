package com.blogmanagement.blogmanagement.Pojo;

import lombok.Data;

@Data
public class GetCategories {
    private String name;
    private Integer id;
}
