package com.blogmanagement.blogmanagement.Pojo;

import lombok.Data;

@Data
public class Number {
    private Integer thumbupnum;
    private Integer commentnum;
    private Integer readnum;
    private Integer collectnum;
}
