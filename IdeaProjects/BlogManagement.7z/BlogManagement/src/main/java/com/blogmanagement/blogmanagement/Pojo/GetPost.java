package com.blogmanagement.blogmanagement.Pojo;

import lombok.Data;

@Data
public class GetPost {
    private String name;
    private String article;
    private String time;
}
