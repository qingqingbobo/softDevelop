package com.blogmanagement.blogmanagement.Pojo;

import lombok.Data;

@Data
public class CollectMessage {
    private String name;
    private String blogName;
    private String commentDate;
    private String avatarUrl;
}
