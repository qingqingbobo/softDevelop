package com.blogmanagement.blogmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlogManagementApplicationTests {

    @Test
    void contextLoads() {
    }

}
